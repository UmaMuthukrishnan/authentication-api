## Technical stack requirements
Maven,
JDK 8,
Spring Boot 2.2.6,Spring MVC
Data Persistence:In-Memory (ChronicleMap)

## Approach: 

I have implemented Spring Security Authentication for authenticating the user credentials.

For Data persistence,I have used ChronicleMap as it is fast,reliable and better than ConcurrentHashMap.

Used RestTemplate for consuming AccountAPI service details.

It is exposed on port 8084 via TLS

##About : Authentication-API service

Authentication-API service authenticates the user details both for creating \
    i) An OnlineUserAccount for a valid AccountNumber\
    ii)A JWT token for an authenticated user.
 
 I have created two separate services namely,
 
 OnlineAccountService -  For managing  OnlineAccount\
 AuthenticationService - For managing User Authentication
 
 Right now, the services are just holding an endpoint each ,but it is good have separated instead 
 of having everything together.This makes use of principle "Separation of Concerns".
 
 For creating an OnlineAccountService,user should provide below valid credentials,\
        i)userName - Unique name (case-insensitive)
        ii)password -Characters greater than or equal to 6
        iii)accountNumber -Valid Account number from AccountAPI
        
and the above can be accessed via,

 POST /accountAuthentication/createOnlineAccount (with ResponseBody as below)
             
    {
    userName:"",
    password:"",
    accountNumber:""
    }
        
 For creating a valid JWT token ,user should provide below valid credentials.\
         i)userName - Existing name (case-insensitive) in OnlineUserAccount(in-Memory)\
         ii)password - Related to userName(Characters greater than or equal to 6)
 
 POST /accountAuthentication/authenticateUser (with ResponseBody as below)
              
     {
     username:"",
     password:""
     }
 If user tries to enter  a wrong password for 3 consecutive times, then his account 
 will be blocked for 24 hours.

 
## Steps to be followed for accessing endpoints.

1. Create Maven-build and make the jar available locally(mvn clean install)
2. Start wire-mock bash script(sh start-wiremock.sh)
3. Start authentication-api service
4. Verify the endpoints via PostMan / RestClient
5. The authentication-api service can be accessed via,
        https://localhost:8084/accountAuthentication

