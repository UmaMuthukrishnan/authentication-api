package com.authentication.rest.config;

import com.authentication.rest.repository.InMemoryOnlineAccountUserRepository;
import com.authentication.rest.repository.OnlineAccountUserRepository;
import com.authentication.rest.security.LoginDetailsService;
import com.authentication.rest.security.LoginUserDetailsService;
import com.authentication.rest.security.LoginValidationService;
import com.authentication.rest.service.AuthenticationService;
import com.authentication.rest.service.OnlineAccountService;
import com.authentication.rest.service.impl.AuthenticationServiceImpl;
import com.authentication.rest.service.impl.OnlineAccountServiceImpl;
import com.authentication.rest.serviceclient.AccountAPIServiceClient;
import com.authentication.rest.util.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;

/**
 * SecurityConfigTest config for Integrated test
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true)
@ActiveProfiles("security")
public class SecurityConfigTest extends WebSecurityConfigurerAdapter {
    @Bean
    public LoginDetailsService loginDetailsService() {
        return new LoginDetailsService();
    }

    @Bean
    public LoginValidationService loginValidationService() {
        return new LoginValidationService();
    }

    @Bean
    public OnlineAccountUserRepository onlineAccountUserRepository() {
        return new InMemoryOnlineAccountUserRepository(passwordEncoder());
    }

    @Bean
    JwtTokenUtil jwtTokenUtil() {
        return new JwtTokenUtil();
    }

    @Bean
    public AuthenticationService authenticationService() throws Exception {
        return new AuthenticationServiceImpl((LoginUserDetailsService) loginUserDetailsService(), jwtTokenUtil(),
                authenticationManager(), loginDetailsService());
    }

    @MockBean
    AccountAPIServiceClient accountAPIServiceClient;

    @Bean
    OnlineAccountService onlineAccountService() {
        return new OnlineAccountServiceImpl(accountAPIServiceClient, onlineAccountUserRepository(), passwordEncoder());
    }

    @Qualifier("loginUserDetailsService")
    @Bean
    public UserDetailsService loginUserDetailsService() {
        return new LoginUserDetailsService(onlineAccountUserRepository()
                , loginValidationService(), loginDetailsService());
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        // configure AuthenticationManager so that it knows from where to load
        // user for matching credentials
        // Use BCryptPasswordEncoder
        auth.userDetailsService(loginUserDetailsService()).passwordEncoder(passwordEncoder());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //http.csrf().disable().
        http.
                authorizeRequests()
                .antMatchers("/**")
                .permitAll()
                .and().httpBasic();
    }

}
