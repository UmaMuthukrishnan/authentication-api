package com.authentication.rest.service.impl;

import com.authentication.rest.exception.InvalidAccountDetailsException;
import com.authentication.rest.exception.UserAccountExistsException;
import com.authentication.rest.exception.UserNameExistsException;
import com.authentication.rest.model.OnlineAccountUser;
import com.authentication.rest.repository.InMemoryOnlineAccountUserRepository;
import com.authentication.rest.repository.OnlineAccountUserRepository;
import com.authentication.rest.request.OnlineAccountRequest;
import com.authentication.rest.response.AccountCreationResponse;
import com.authentication.rest.service.OnlineAccountService;
import com.authentication.rest.serviceclient.AccountAPIServiceClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

import static org.mockito.Mockito.when;

/**
 * Unit Testcase Class for OnlineAccountService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
public class OnlineAccountServiceImplTest {

    private OnlineAccountService onlineAccountService;

    private OnlineAccountUserRepository onlineAccountUserRepository;

    private PasswordEncoder passwordEncoder;

    @Mock
    AccountAPIServiceClient accountAPIServiceClient;

    @Before
    public void setUp() {
        passwordEncoder = new BCryptPasswordEncoder();
        onlineAccountUserRepository = new InMemoryOnlineAccountUserRepository(passwordEncoder);
        onlineAccountService = new OnlineAccountServiceImpl(accountAPIServiceClient, onlineAccountUserRepository, passwordEncoder);
    }

    /**
     * Test to check if a user with Valid credentials
     * <p>
     * {userName,Password & Valid account in AccountAPI} is able to create an Online user account
     */
    @Test
    public void testCreateNewOnlineAccount_WithValidData() {
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("7890511509");
        onlineAccountRequest.setUserName("TestUser");
        onlineAccountRequest.setPassword("test");
        String accountAPIResponse = "{iban:\"NL24ABC7890511509\", ownerId:\"d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d\"}";
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber())).thenReturn(Optional.of(accountAPIResponse));
        AccountCreationResponse response = onlineAccountService.createNewOnlineAccount(onlineAccountRequest);
        Assert.assertNotNull(response);
        String message = "Online User Account has been created successfully!!";
        Assert.assertEquals(message, response.getResponse());
    }

    /**
     * Test to check if a user with Valid credentials
     * <p>
     * {userName,Password & invalid account in AccountAPI} is not able to create an Online user account
     *
     * @throws com.authentication.rest.exception.InvalidAccountDetailsException -Exception
     */
    @Test(expected = InvalidAccountDetailsException.class)
    public void testCreateNewOnlineAccount_WithEmptyAPIResponse(){
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("123456");
        onlineAccountRequest.setUserName("TestUser");
        onlineAccountRequest.setPassword("test");
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber())).thenReturn(Optional.empty());
        onlineAccountService.createNewOnlineAccount(onlineAccountRequest);
    }

    /**
     * Test to check if a user with InValid credentials
     * <p>
     * {existing userName,Password & Valid account in AccountAPI} is not able to create an Online user account
     *
     * @throws com.authentication.rest.exception.UserNameExistsException -Exception
     */
    @Test(expected = UserNameExistsException.class)
    public void testCreateNewOnlineAccount_WithExistingUserName() {
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("7890511462");
        onlineAccountRequest.setUserName("TestUser");
        onlineAccountRequest.setPassword("testUser");
        String accountAPIResponse = "{iban:\"NL24ABC7890511462\", ownerId:\"c56e3d46-aa6d-4dbd-93c1-5f7e95f0334d\"}";
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber())).thenReturn(Optional.of(accountAPIResponse));
        onlineAccountService.createNewOnlineAccount(onlineAccountRequest);
    }

    /**
     * Test to check if a user with InValid credentials
     * <p>
     * {userName,Password & already created online account } is not able to create an Online user account
     *
     * @throws com.authentication.rest.exception.UserAccountExistsException -Exception
     */
    @Test(expected = UserAccountExistsException.class)
    public void testCreateNewOnlineAccount_ForExistingAccount() {
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("7890511509");
        onlineAccountRequest.setUserName("TestUserNew");
        onlineAccountRequest.setPassword("testUser");
        String accountAPIResponse = "{iban:\"NL24ABC7890511509\", ownerId:\"d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d\"}";
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber())).thenReturn(Optional.of(accountAPIResponse));
        onlineAccountService.createNewOnlineAccount(onlineAccountRequest);
    }

}
