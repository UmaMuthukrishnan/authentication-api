package com.authentication.rest.config;

import com.authentication.rest.controller.AccountAuthenticationController;
import com.authentication.rest.repository.InMemoryOnlineAccountUserRepository;
import com.authentication.rest.repository.OnlineAccountUserRepository;
import com.authentication.rest.restTemplate.AccountAPIRestTemplateCustomizer;
import com.authentication.rest.security.LoginDetailsService;
import com.authentication.rest.security.LoginUserDetailsService;
import com.authentication.rest.security.LoginValidationService;
import com.authentication.rest.service.AuthenticationService;
import com.authentication.rest.service.OnlineAccountService;
import com.authentication.rest.service.impl.AuthenticationServiceImpl;
import com.authentication.rest.service.impl.OnlineAccountServiceImpl;
import com.authentication.rest.serviceclient.AccountAPIServiceClient;
import com.authentication.rest.util.JwtTokenUtil;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * ApplicationTestConfig config for Integrated test
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Configuration
@PropertySource("classpath:application.properties")
@EnableWebMvc
public class ApplicationTestConfig implements WebMvcConfigurer {
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public OnlineAccountUserRepository onlineAccountUserRepository() {
        return new InMemoryOnlineAccountUserRepository(passwordEncoder());
    }

    @Bean
    AccountAPIRestTemplateCustomizer customizer() {
        return new AccountAPIRestTemplateCustomizer();
    }

    @Bean
    AccountAPIServiceClient client() {
        return new AccountAPIServiceClient(new RestTemplateBuilder(customizer()));
    }

    @Bean
    OnlineAccountService onlineAccountService() {
        return new OnlineAccountServiceImpl(client(), onlineAccountUserRepository(), passwordEncoder());
    }

    @Bean
    public LoginDetailsService loginDetailsService() {
        return new LoginDetailsService();
    }

    @Bean
    public LoginValidationService loginValidationService() {
        return new LoginValidationService();
    }

    @Bean
    public JwtTokenUtil jwtTokenUtil() {
        return new JwtTokenUtil();
    }

    @Bean
    LoginUserDetailsService loginUserDetailsService() {
        return new LoginUserDetailsService(onlineAccountUserRepository(), loginValidationService(), loginDetailsService());
    }

    @MockBean
    AuthenticationManager authenticationManager;

    @Bean
    AuthenticationService authenticationService() {
        return new AuthenticationServiceImpl(loginUserDetailsService()
                , jwtTokenUtil(), authenticationManager, loginDetailsService());
    }


    @Bean
    AccountAuthenticationController accountAuthenticationController() {
        return new
                AccountAuthenticationController(onlineAccountService(), authenticationService());
    }

}
