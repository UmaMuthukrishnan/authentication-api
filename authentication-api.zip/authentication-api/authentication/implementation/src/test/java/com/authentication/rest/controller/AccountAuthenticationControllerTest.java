package com.authentication.rest.controller;

import com.authentication.rest.config.APIConstants;
import com.authentication.rest.config.ApplicationTestConfig;
import com.authentication.rest.model.OnlineAccountUser;
import com.authentication.rest.repository.OnlineAccountUserRepository;
import com.authentication.rest.request.LoginRequest;
import com.authentication.rest.request.OnlineAccountRequest;
import com.authentication.rest.security.LoginValidationService;
import com.authentication.rest.serviceclient.AccountAPIServiceClient;
import com.authentication.rest.util.JwtTokenUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.util.NestedServletException;

import java.util.ArrayList;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integrated Testcase Class - AccountAuthenticationController
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(
        classes = {ApplicationTestConfig.class})
@WebAppConfiguration

public class AccountAuthenticationControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;
    public MockMvc mockMvc;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @MockBean
    AccountAPIServiceClient accountAPIServiceClient;

    @Mock
    JwtTokenUtil jwtTokenUtil;

    @MockBean
    LoginValidationService loginValidationService;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    OnlineAccountUserRepository onlineAccountUserRepository;

    @Before
    public void setUp() {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();

    }

    /**
     * Test to check if a user with Valid credentials
     *
     * {userName,Password & Valid account in AccountAPI} is able to create an Online user account
     *
     */

    @Test
    public void testToCreateOnlineAccount_WithValidCredentials() throws Exception {
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("7890511589");
        onlineAccountRequest.setUserName("TestNewUser");
        onlineAccountRequest.setPassword("test1234");
        String accountAPIResponse = "{iban:\"NL24ABC7890511509\", ownerId:\"d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d\"}";
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber()))
                .thenReturn(Optional.of(accountAPIResponse));
        mockMvc.perform(post("/accountAuthentication/createOnlineAccount")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(onlineAccountRequest)))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(jsonPath("$.response", notNullValue()))
                .andExpect(jsonPath("$.response", is(APIConstants.SUCCESS_MESSAGE)));

    }

    /**
     * Test to check if a user with InValid credentials
     *
     * {userName,Invalid Password & Valid account in AccountAPI} is not able to create an Online user account
     * @throws com.authentication.rest.exception.InvalidRequestException -Exception
     *
     */

    @Test
    public void testToCreateOnlineAccount_WithInvalidPassword() throws Exception {
        thrown.expect(NestedServletException.class);
        thrown.expectMessage("Enter a valid request");
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("7890511509");
        onlineAccountRequest.setUserName("TestUser");
        onlineAccountRequest.setPassword("test");
        mockMvc.perform(post("/accountAuthentication/createOnlineAccount")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(onlineAccountRequest)))
                .andReturn();
    }

    /**
     * Test to check if a user with Valid credentials
     *
     * {userName,Password & invalid account in AccountAPI} is not able to create an Online user account
     *
     * @throws com.authentication.rest.exception.InvalidAccountDetailsException -Exception
     *
     */

    @Test
    public void testToCreateOnlineAccount_WithEmptyAPIResponse() throws Exception {
        thrown.expect(NestedServletException.class);
        thrown.expectMessage("Please enter valid account details");
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("123456");
        onlineAccountRequest.setUserName("TestUser");
        onlineAccountRequest.setPassword("test123");
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber())).thenReturn(Optional.empty());
        mockMvc.perform(post("/accountAuthentication/createOnlineAccount")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(onlineAccountRequest)))
                .andReturn();
    }

    /**
     * Test to check if a user with InValid credentials
     *
     * {existing userName,Password & Valid account in AccountAPI} is not able to create an Online user account
     *
     * @throws com.authentication.rest.exception.UserNameExistsException -Exception
     *
     */

    @Test
    public void testCreateNewOnlineAccount_WithExistingUserName() throws Exception {
        thrown.expect(NestedServletException.class);
        thrown.expectMessage("UserName already exists!!");
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511585")
                .ibanNumber("NL24ABC7890511567")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("7890511562");
        onlineAccountRequest.setUserName("TestUser");
        onlineAccountRequest.setPassword("testUser");
        String accountAPIResponse = "{iban:\"NL24ABC7890511462\", ownerId:\"c56e3d46-aa6d-4dbd-93c1-5f7e95f0334d\"}";
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber())).thenReturn(Optional.of(accountAPIResponse));
        mockMvc.perform(post("/accountAuthentication/createOnlineAccount")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(onlineAccountRequest)))
                .andReturn();
    }

    /**
     * Test to check if a user with InValid credentials
     *
     * {userName,Password & already created online account } is not able to create an Online user account
     *
     * @throws com.authentication.rest.exception.UserAccountExistsException -Exception
     *
     */

    @Test
    public void testCreateNewOnlineAccount_ForExistingAccount() throws Exception {
        thrown.expect(NestedServletException.class);
        thrown.expectMessage("Online Account already exists!!");
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        OnlineAccountRequest onlineAccountRequest = new OnlineAccountRequest();
        onlineAccountRequest.setAccountNumber("7890511509");
        onlineAccountRequest.setUserName("TestUserNew");
        onlineAccountRequest.setPassword("testUser");
        String accountAPIResponse = "{iban:\"NL24ABC7890511509\", ownerId:\"d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d\"}";
        when(accountAPIServiceClient.getAccountAPIDetails(onlineAccountRequest.getAccountNumber())).thenReturn(Optional.of(accountAPIResponse));
        mockMvc.perform(post("/accountAuthentication/createOnlineAccount")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(onlineAccountRequest)))
                .andReturn();
    }

    /**
     * Test to check if a user with valid credentials
     *
     * {userName,Password } gets authenticated and able to generate JWT Token
     *
     *
     */

    @Test
    public void testToGetAuthenticationToken_WithValidCredentials() throws Exception {
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test123"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("TestUser");
        loginRequest.setPassword("test123");
        UserDetails userDetails = new User(loginRequest.getUsername()
                , passwordEncoder.encode(loginRequest.getPassword()),
                new ArrayList<>());
        String dummyToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJUZXN0VXNlciIsImV4cCI6MTU4OTc2NDkzMSwiaWF0IjoxNTg5NzQ2OTMxfQ.c8Drhuv2GWRrz-V7DOv7rZQMNfzjULHc8RxO9-9M02cNuaCloECytDGFStZSn5MRIr4CJGegBeeL7GvHt-Zxv9B_aJmxipOyywLiQ2WxWE9Q9Ljs8WLDSqhipPQYrbA8RQwmGkyY_AgisDJXZm19G6DowBUFlxgGNVtY7a9ORzrBiBojvFJSRlZkrT3CVEw0XIFW-PQ8wBpcOhpMcQKXO-lL1jKa2ay-rlxnuEGhGI1VE3PlwJLXoSauRSFvolBvuPfKffo6ErWOFauTTYCbN405b84rAHy0lFqE5dV41rQob9y6dic4nip35HLJ_cfNUN3W7is7gXqOHgUpx1uwfhIHZH10ocWKVfdc1Y5HYgH0q8dQBA6GlStTRoQ9E5uC7ifMFa1swSA006EupB6DSzK3wHaPjutZ0SxiH8TwsTHC9IE_miuq0woEZvcircT1KCDMVFmGMGdDxbZhH7qPcP8SU20TaXH1ZdTs4xbIzaE61KFnBL8UrgZN7Bn8zG6hZuk8fMzf0JVVypEe7MUA-tJ7cmWG2K7a_0C8pvfQ6221kWge69W2mfstwavaQsm-nc5rWGeAPWPHvJW_xhREenKDtgM2V17WoVjFnJworKkYerHhadM4dA0Vy8TFQJqXQdMRzFOUqf5fPYgIBjCNWqXhr8J7REimiJida-TFUpQ";
        when(jwtTokenUtil.generateToken(userDetails)).thenReturn(dummyToken);
        mockMvc.perform(post("/accountAuthentication/authenticateUser")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(loginRequest)))
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.jwtToken", notNullValue()));
    }

    /**
     * Test to check if a user with Invalid credentials
     *
     * {invalid userNam &,Password } is not able to generate JWT Token
     *
     * @throws org.springframework.security.core.userdetails.UsernameNotFoundException -Exception
     *
     *
     */

    @Test
    public void testGetAuthenticationToken_InvalidUser() throws Exception {
        thrown.expect(NestedServletException.class);
        thrown.expectMessage("User not found with given credentials");
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("testuser"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("NewUser");
        loginRequest.setPassword("testuser");
        mockMvc.perform(post("/accountAuthentication/authenticateUser")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(loginRequest)))
                .andReturn();
    }

    /**
     * Test to check if a user tried with Invalid credentials for more than 3 times
     *
     * {invalid userNam &,Password } is not able to generate JWT Token
     *
     * @throws com.authentication.rest.exception.UserAccountBlockedException -Exception
     *
     *
     */

    @Test
    public void testGetAuthenticationToken_UserBlocked() throws Exception {
        thrown.expect(NestedServletException.class);
        thrown.expectMessage("User Account is locked!");
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        when(loginValidationService.isBlocked("TestUser")).thenReturn(true);
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("TestUser");
        loginRequest.setPassword("test1");
        mockMvc.perform(post("/accountAuthentication/authenticateUser")
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .content(getValueAsString(loginRequest)))
                .andReturn();
    }

    private String getValueAsString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

}
