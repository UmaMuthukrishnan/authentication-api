package com.authentication.rest.service.impl;

import com.authentication.rest.config.SecurityConfigTest;
import com.authentication.rest.exception.UserAccountBlockedException;
import com.authentication.rest.model.OnlineAccountUser;
import com.authentication.rest.repository.OnlineAccountUserRepository;
import com.authentication.rest.request.LoginRequest;
import com.authentication.rest.response.JwtResponse;
import com.authentication.rest.security.LoginDetailsService;
import com.authentication.rest.security.LoginUserDetailsService;
import com.authentication.rest.security.LoginValidationService;
import com.authentication.rest.service.AuthenticationService;
import com.authentication.rest.util.JwtTokenUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

/**
 * Unit Testcase Class for AuthenticationService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ActiveProfiles("security")
@ContextConfiguration(
        classes = {SecurityConfigTest.class})
public class AuthenticationServiceImplTest {

    private AuthenticationService authenticationService;
    @Mock
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private LoginDetailsService loginDetailsService;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @MockBean
    private LoginValidationService loginValidationService;

    @Qualifier(value = "loginUserDetailsService")
    @Autowired
    private UserDetailsService loginUserDetailsService;
    @Autowired
    private OnlineAccountUserRepository onlineAccountUserRepository;

    @Before
    public void setUp() {
        authenticationService = new AuthenticationServiceImpl((LoginUserDetailsService) loginUserDetailsService
                , jwtTokenUtil, authenticationManager, loginDetailsService);
    }

    /**
     * Test to check if a user with valid credentials
     * <p>
     * {userName,Password } gets authenticated and able to generate JWT Token
     */
    @Test
    public void testToGetAuthenticationToken_WithValidCredentials() throws Exception {
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("TestUser");
        loginRequest.setPassword("test");
        UserDetails userDetails = new User(loginRequest.getUsername()
                , passwordEncoder.encode(loginRequest.getPassword()),
                new ArrayList<>());
        String jwtToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
        when(jwtTokenUtil.generateToken(userDetails)).thenReturn(jwtToken);
        JwtResponse response = authenticationService.getAuthenticationToken(loginRequest);
        Assert.assertEquals(jwtToken, response.getJwtToken());
    }

    /**
     * Test to check if a user with Invalid credentials
     * <p>
     * {invalid userNam &,Password } is not able to generate JWT Token
     *
     * @throws org.springframework.security.core.userdetails.UsernameNotFoundException -Exception
     */
    @Test(expected = UsernameNotFoundException.class)
    public void testGetAuthenticationToken_InvalidUser() throws Exception {
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("NewUser");
        loginRequest.setPassword("test");
        authenticationService.getAuthenticationToken(loginRequest);
    }

    /**
     * Test to check if a user tried with Invalid credentials for more than 3 times
     * <p>
     * {invalid userNam &,Password } is not able to generate JWT Token
     *
     * @throws com.authentication.rest.exception.UserAccountBlockedException -Exception
     */
    @Test(expected = UserAccountBlockedException.class)
    public void testGetAuthenticationToken_UserBlocked() throws Exception {
        OnlineAccountUser existingUser = OnlineAccountUser.builder().userName("TestUser")
                .accountNumber("7890511509")
                .ibanNumber("NL24ABC7890511509")
                .ownerId("d23e3d46-aa6d-4dbd-93c1-5f7e95f0334d")
                .password(passwordEncoder.encode("test"))
                .build();
        onlineAccountUserRepository.save(existingUser);
        when(loginValidationService.isBlocked("TestUser")).thenReturn(true);
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("TestUser");
        loginRequest.setPassword("test1");
        authenticationService.getAuthenticationToken(loginRequest);
    }

}
