package com.authentication.rest.security;

import com.authentication.rest.config.APIConstants;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * LoginValidationService class for validating invalidAttempt of user
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class LoginValidationService {
    private final LoadingCache<String, Integer> attemptsCache;

    public LoginValidationService() {
        super();
        attemptsCache = CacheBuilder.newBuilder().expireAfterWrite(1, TimeUnit.DAYS).build(new CacheLoader<String, Integer>() {
            @Override
            public Integer load(final String key) {
                return 0;
            }
        });
    }

    /**
     * Method to log the number of failed attempts the user tried with his credentials.
     * This stores the data in a cache based on username with his number of attempts.
     * This method will be triggered once AuthenticationFailureListener is invoked
     *
     * @param key userName as key value
     */
    public void loginFailed(final String key) {
        int attempts;
        try {
            attempts = attemptsCache.get(key);
        } catch (final ExecutionException e) {
            attempts = 0;
        }
        attempts++;
        attemptsCache.put(key, attempts);
    }

    /**
     * Method to validate if the number of invalid attempts of user equal/exceeds the Maximum limit.
     * If yes then,it blocks the user for next 24 hours by writing it to a cache.
     *
     * @param key userName as key value
     * @return boolean true -for user blocked and false for user to have a chance.
     */
    public boolean isBlocked(final String key) {
        try {
            return attemptsCache.get(key) >= APIConstants.INVALID_MAX_ATTEMPT;
        } catch (final ExecutionException e) {
            return false;
        }
    }
}
