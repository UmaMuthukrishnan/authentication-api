package com.authentication.rest.util;

import com.authentication.rest.exception.InvalidRequestException;
import com.authentication.rest.model.AuthenticationApiError;
import com.authentication.rest.request.LoginRequest;
import com.authentication.rest.request.OnlineAccountRequest;
import org.springframework.http.HttpStatus;
import shaded.org.codehaus.plexus.util.StringUtils;
import com.authentication.rest.config.APIConstants;

/**
 * UserRequestValidator class to validate the user entered details
 */
public class UserRequestValidator {

    /**
     * Method to validate user entered OnlineAccountRequest .
     *
     * @param onlineAccountRequest Request with { String userName,String Password,String accountNumber}
     *                             in json format
     */
    public static void validateOnlineAccountRequest(OnlineAccountRequest onlineAccountRequest) {
        if (onlineAccountRequest == null || StringUtils.isBlank(onlineAccountRequest.getAccountNumber())
                || StringUtils.isBlank(onlineAccountRequest.getUserName())
                || (StringUtils.isBlank(onlineAccountRequest.getPassword())) ||
                org.springframework.util.StringUtils.trimAllWhitespace(onlineAccountRequest.getPassword())
                        .length() < 6) {

            throw new InvalidRequestException
                    (new AuthenticationApiError(APIConstants.INVALID_ACCOUNT_CREATION_REQUEST_ERROR_CODE,
                            APIConstants.INVALID_ACCOUNT_CREATION_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
    }

    /**
     * Method to validate user entered LoginRequest .
     *
     * @param loginRequest Request with { String username,String Password}
     *                     in json format
     */
    public static void validateLoginRequest(LoginRequest loginRequest) {
        if (loginRequest == null || StringUtils.isBlank(loginRequest.getUsername())
                || StringUtils.isBlank(loginRequest.getPassword()) &&
                org.springframework.util.StringUtils.trimAllWhitespace(loginRequest.getPassword())
                        .length() < 6) {

            throw new InvalidRequestException
                    (new AuthenticationApiError(APIConstants.INVALID_LOGIN_REQUEST_ERROR_CODE,
                            APIConstants.INVALID_LOGIN_REQUEST_ERROR_DESC,
                            HttpStatus.BAD_REQUEST), "Enter a valid request");
        }
    }
}
