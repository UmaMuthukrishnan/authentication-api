package com.authentication.rest.util;

import com.authentication.rest.config.APIConstants;
import com.authentication.rest.exception.KeyPairCreationException;
import com.authentication.rest.model.AuthenticationApiError;
import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.security.*;
import java.security.cert.Certificate;

import java.security.cert.CertificateException;
import java.util.*;

/**
 * JwtTokenUtil class to generate JWT token
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class JwtTokenUtil implements Serializable {

    private static final long serialVersionUID = -2550185165626007488L;

    @Value("${server.ssl.key-store}")
    private String authenticationAPIKeyStore;

    @Value("${server.ssl.key-store-password}")
    private String authenticationAPIKeyStorePassword;

    @Value("${server.ssl.key-store-type}")
    private String authenticationAPIKeyStoreType;

    /**
     * Method to generate a JWT valid Token for the userCredentials
     *
     * @param userDetails authenticated userDetails
     * @return JWT token as String
     */
    public String generateToken(UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        return doGenerateToken(claims, userDetails.getUsername());
    }

    /**
     * Actual method to generate the JWT token.
     * Token has been created by considering claims of the token, like Issuer
     * , Expiration, Subject, and the ID.It has been signed with
     * using the "RS256 algorithm" and "Private key".
     * <p>
     * Generated JWT token can be validated using valid public key generated from the keystore.
     *
     * @param claims  like Issuer,Expiration, Subject, and the ID
     * @param subject userName
     * @return valid JWT token signed with "RS256 algorithm" and "Private key"
     */
    private String doGenerateToken(Map<String, Object> claims, String subject) {
        Key privateKey = getKeyPair().getPrivate();
        Header<?> header = Jwts.header();
        header.setType("JWT");
        return Jwts.builder()
                .setHeader((Map<String, Object>) header)
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + APIConstants.JWT_TOKEN_VALIDITY * 1000))
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact();
    }

    /**
     * Method to retrieve the KeyPair from authentication-api Keystore placed in classpath
     *
     * @return KeyPair with PublicKey & PrivateKey
     */
    private KeyPair getKeyPair() {
        KeyPair keyPair = null;
        Key key;
        PublicKey publicKey;
        try {
            KeyStore ks = KeyStore.getInstance(authenticationAPIKeyStoreType);
            ks.load(new FileInputStream(ResourceUtils.getFile(authenticationAPIKeyStore)), authenticationAPIKeyStorePassword.toCharArray());
            key = ks.getKey("authentication-api", authenticationAPIKeyStorePassword.toCharArray());

            if (key instanceof PrivateKey) {
                // Get certificate of public key
                Certificate cert = ks.getCertificate("authentication-api");
                // Get public key
                publicKey = cert.getPublicKey();
                keyPair = new KeyPair(publicKey, (PrivateKey) key);

            }

        } catch (IOException e) {
            throw new KeyPairCreationException(new AuthenticationApiError(APIConstants.FILE_NOT_EXISTS_ERROR_CODE
                    , APIConstants.FILE_NOT_EXISTS_ERROR_DESC, HttpStatus.NOT_FOUND), "File Not Found");
        } catch (CertificateException e) {
            throw new KeyPairCreationException(new AuthenticationApiError(APIConstants.CERTIFICATE_ERROR_CODE
                    , APIConstants.CERTIFICATE_ERROR_DESC, HttpStatus.BAD_REQUEST), "Certificate Error!!");
        } catch (NoSuchAlgorithmException e) {
            throw new KeyPairCreationException(new AuthenticationApiError(APIConstants.NO_SUCH_ALGORITHM_ERROR_CODE
                    , APIConstants.NO_SUCH_ALGORITHM_ERROR_DESC, HttpStatus.NOT_FOUND), "No such algorithm exists!!");
        } catch (UnrecoverableKeyException e) {
            throw new KeyPairCreationException(new AuthenticationApiError(APIConstants.NOT_RECOVERABLE_KEY_ERROR_CODE
                    , APIConstants.NOT_RECOVERABLE_KEY_ERROR_DESC, HttpStatus.BAD_REQUEST), "Not Recoverable Key");
        } catch (KeyStoreException e) {
            throw new KeyPairCreationException(new AuthenticationApiError(APIConstants.KEY_STORE_ERROR_CODE
                    , APIConstants.KEY_STORE_ERROR_DESC, HttpStatus.BAD_REQUEST), "Key Store Error!!");
        }
        return keyPair;
    }

}
