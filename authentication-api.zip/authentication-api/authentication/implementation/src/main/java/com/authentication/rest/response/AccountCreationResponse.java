package com.authentication.rest.response;

import lombok.*;
import org.springframework.stereotype.Component;

/**
 * AccountCreationResponse class to show Successful OnlineAccountUser creation
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountCreationResponse {

    private String response;
}
