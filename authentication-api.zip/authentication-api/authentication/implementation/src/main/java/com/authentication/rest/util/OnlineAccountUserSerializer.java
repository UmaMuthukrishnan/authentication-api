package com.authentication.rest.util;

import com.authentication.rest.model.OnlineAccountUser;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.hash.serialization.BytesReader;
import net.openhft.chronicle.hash.serialization.BytesWriter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * OnlineAccountUserSerializer class to serialize OnlineAccountUser
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

public class OnlineAccountUserSerializer implements BytesReader<OnlineAccountUser>, BytesWriter<OnlineAccountUser> {

    private static final OnlineAccountUserSerializer instance = new OnlineAccountUserSerializer();

    public static OnlineAccountUserSerializer getInstance() {
        return instance;
    }

    private OnlineAccountUserSerializer() {
    }

    @NotNull
    @Override
    public OnlineAccountUser read(Bytes in, @Nullable OnlineAccountUser using) {
        if (using == null) {
            using = new OnlineAccountUser();
        }
        using.setIbanNumber(in.read8bit());
        using.setAccountNumber(in.read8bit());
        using.setUserName(in.read8bit());
        using.setOwnerId(in.read8bit());
        using.setPassword(in.read8bit());
        return using;
    }

    @Override
    public void write(Bytes out, @NotNull OnlineAccountUser toWrite) {
        out.write8bit(toWrite.getIbanNumber());
        out.write8bit(toWrite.getAccountNumber());
        out.write8bit(toWrite.getUserName());
        out.write8bit(toWrite.getOwnerId());
        out.write8bit(toWrite.getPassword());

    }

}
