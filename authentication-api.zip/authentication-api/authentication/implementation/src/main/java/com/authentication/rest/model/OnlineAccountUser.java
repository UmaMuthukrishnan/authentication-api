package com.authentication.rest.model;

import lombok.*;
import org.springframework.stereotype.Component;

/**
 * OnlineAccountUser Model class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OnlineAccountUser {
    private String userName;
    private String accountNumber;
    private String password;
    private String ibanNumber;
    private String ownerId;
}
