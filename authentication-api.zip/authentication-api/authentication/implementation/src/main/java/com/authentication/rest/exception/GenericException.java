package com.authentication.rest.exception;

import com.authentication.rest.model.AuthenticationApiError;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * GenericException Handler for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@NoArgsConstructor
public class GenericException extends RuntimeException {

    private AuthenticationApiError authenticationApiError;

    public GenericException(String description) {
        super(description);
    }

    public GenericException(String description, Exception cause) {
        super(description, cause);
    }

    public GenericException(AuthenticationApiError authenticationApiError) {
        this.authenticationApiError = authenticationApiError;

    }

}
