package com.authentication.rest.exception;

import com.authentication.rest.model.AuthenticationApiError;
import lombok.Getter;

/**
 * UserNameExistsException Exception for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class UserNameExistsException extends GenericException {
    private static final long serialVersionUID = 1L;

    String message;

    public UserNameExistsException(AuthenticationApiError authenticationApiError, String message) {
        super(authenticationApiError);
        this.message = message;

    }
}
