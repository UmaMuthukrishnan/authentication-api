package com.authentication.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * AuthenticationAPIClass -Main Entry point of accessing Authentication-API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@SpringBootApplication
public class AuthenticationAPIClass {
    public static void main(String[] args) {
        SpringApplication.run(AuthenticationAPIClass.class, args);
    }
}
