package com.authentication.rest.exception;

import com.authentication.rest.model.AuthenticationApiError;
import lombok.Getter;

/**
 * InvalidAccountDetailsException Exception for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class RestTemplateCustomizerException extends GenericException {

    String message;

    public RestTemplateCustomizerException(AuthenticationApiError authenticationApiError, String message) {
        super(authenticationApiError);
        this.message = message;

    }
}
