package com.authentication.rest.response;

import com.authentication.rest.model.AuthenticationApiError;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Model class to handle all the API response errors
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@Setter
public class AuthenticationApiErrorResponse {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<AuthenticationApiError> authenticationApiErrorList = new ArrayList<>();
}
