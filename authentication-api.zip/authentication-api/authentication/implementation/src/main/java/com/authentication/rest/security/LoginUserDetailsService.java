package com.authentication.rest.security;

import com.authentication.rest.exception.UserAccountBlockedException;
import com.authentication.rest.model.AuthenticationApiError;
import com.authentication.rest.model.LoginDetails;
import com.authentication.rest.model.OnlineAccountUser;
import com.authentication.rest.repository.OnlineAccountUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

/**
 * LoginUserDetailsService class for validating & authenticating the userCredentials
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
public class LoginUserDetailsService implements UserDetailsService {
    private final OnlineAccountUserRepository onlineAccountUserRepository;

    private final LoginValidationService loginValidationService;


    private final LoginDetailsService loginDetailsService;

    private static final String USER_ACCOUNT_LOCKED_ERROR_CODE = "AUTHAPI-USER_ACCOUNT_LOCKED-011";
    private static final String USER_ACCOUNT_LOCKED_ERROR_DESC = "USER_ACCOUNT_LOCKED";

    @Autowired
    public LoginUserDetailsService(OnlineAccountUserRepository onlineAccountUserRepository, LoginValidationService loginValidationService, LoginDetailsService loginDetailsService) {
        this.onlineAccountUserRepository = onlineAccountUserRepository;
        this.loginValidationService = loginValidationService;
        this.loginDetailsService = loginDetailsService;
    }

    /**
     * Overridden method to validate the user based on the userCredentials .
     * It validates the loggedIn userdetails if exists already in the datastore(in-memory).
     * If user exists,then User will be authenticated else UsernameNotFoundException will be thrown.
     * <p>
     * This method also blocks the user to access his account if he tries to enter
     * a wrong password for 3 consecutive times.
     *
     * @param username valid username
     * @return authenticated UserDetails
     * @throws UsernameNotFoundException when user details are not found in the datastore(in-memory)
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        LoginDetails loginDetails = loginDetailsService.retrieveLoginDetails();
        if (loginValidationService.isBlocked(username)) {
            throw new UserAccountBlockedException(new AuthenticationApiError(USER_ACCOUNT_LOCKED_ERROR_CODE
                    , USER_ACCOUNT_LOCKED_ERROR_DESC, HttpStatus.BAD_REQUEST), "User Account is locked!");
        }
        Optional<OnlineAccountUser> optionalOnlineAccountUser = onlineAccountUserRepository.findByUserNameAndPassword(username, loginDetails.getPassword());
        OnlineAccountUser onlineAccountUser;
        if (optionalOnlineAccountUser.isPresent()) {
            onlineAccountUser = optionalOnlineAccountUser.get();
            return new User(onlineAccountUser.getUserName(), onlineAccountUser.getPassword(),
                    new ArrayList<>());
        } else {
            throw new UsernameNotFoundException("User not found with given credentials");
        }

    }
}
