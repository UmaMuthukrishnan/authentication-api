package com.authentication.rest.response;

import lombok.*;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * JwtResponse class to show created JWT token for authenticated user
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JwtResponse implements Serializable {
    private static final long serialVersionUID = -8091879091924046844L;
    private String jwtToken;
}
