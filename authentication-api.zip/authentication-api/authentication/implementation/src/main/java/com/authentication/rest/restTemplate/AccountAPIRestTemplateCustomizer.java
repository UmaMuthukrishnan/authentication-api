package com.authentication.rest.restTemplate;

import com.authentication.rest.config.APIConstants;
import com.authentication.rest.exception.RestTemplateCustomizerException;
import com.authentication.rest.model.AuthenticationApiError;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateCustomizer;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

/**
 * AccountAPIRestTemplateCustomizer class for customizing restTemplate for AccountAPI access
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class AccountAPIRestTemplateCustomizer implements RestTemplateCustomizer {

    @Value("${account-api-key-store}")
    private String accountAPIKeyStore;

    @Value("${account-api-trust-store}")
    private String accountAPITrustStore;

    @Value("${account-api-key-store-password}")
    private String accountAPIKeyStorePassword;

    @Value("${account-api-trust-store-password}")
    private String accountAPITrustStorePassword;

    @Value("${account-api-connection-protocol}")
    private String accountAPIConnectionProtocol;

    /**
     * Overridden method to customize the restTemplate which is used for accessing AccountAPI
     * Loads all the properties for getting AccountAPI Keystore & TrustStore details from the classpath
     * to customize the SSLContext .This is used for accessing AccountAPI which
     * exposes a mutual TLS connector on port 8444
     *
     * @param restTemplate RestTemplate which can be used for connecting with AccountAPI from AuthenticationAPI
     */
    @Override
    public void customize(RestTemplate restTemplate) {
        SSLContext sslContext;
        try {
            sslContext = SSLContextBuilder
                    .create()
                    .loadKeyMaterial(ResourceUtils.getFile(accountAPIKeyStore),
                            accountAPIKeyStorePassword.toCharArray(), accountAPIKeyStorePassword.toCharArray())
                    .loadTrustMaterial(ResourceUtils.getFile(accountAPITrustStore), accountAPITrustStorePassword.toCharArray())
                    .setProtocol(accountAPIConnectionProtocol)
                    .build();
        } catch (IOException e) {
            throw new RestTemplateCustomizerException(new AuthenticationApiError(APIConstants.FILE_NOT_EXISTS_ERROR_CODE
                    , APIConstants.FILE_NOT_EXISTS_ERROR_DESC, HttpStatus.NOT_FOUND), "File Not Found");
        } catch (NoSuchAlgorithmException e) {
            throw new RestTemplateCustomizerException(new AuthenticationApiError(APIConstants.NO_SUCH_ALGORITHM_ERROR_CODE
                    , APIConstants.NO_SUCH_ALGORITHM_ERROR_DESC, HttpStatus.NOT_FOUND), "No such algorithm exists!!");
        } catch (KeyManagementException e) {
            throw new RestTemplateCustomizerException(new AuthenticationApiError(APIConstants.KEY_MANAGEMENT_ERROR_CODE
                    , APIConstants.KEY_MANAGEMENT_ERROR_DESC, HttpStatus.BAD_REQUEST), "Key Management error !!");
        } catch (CertificateException e) {
            throw new RestTemplateCustomizerException(new AuthenticationApiError(APIConstants.CERTIFICATE_ERROR_CODE
                    , APIConstants.CERTIFICATE_ERROR_DESC, HttpStatus.BAD_REQUEST), "Certificate Error!!");
        } catch (KeyStoreException e) {
            throw new RestTemplateCustomizerException(new AuthenticationApiError(APIConstants.KEY_STORE_ERROR_CODE
                    , APIConstants.KEY_STORE_ERROR_DESC, HttpStatus.BAD_REQUEST), "Key Store Error!!");
        } catch (UnrecoverableKeyException e) {
            throw new RestTemplateCustomizerException(new AuthenticationApiError(APIConstants.NOT_RECOVERABLE_KEY_ERROR_CODE
                    , APIConstants.NOT_RECOVERABLE_KEY_ERROR_DESC, HttpStatus.BAD_REQUEST), "Not Recoverable Key");
        }

        CloseableHttpClient client = HttpClients.custom()
                .setSSLContext(sslContext)
                .build();

        HttpComponentsClientHttpRequestFactory requestFactory
                = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setConnectTimeout(10000);
        requestFactory.setReadTimeout(10000);
        requestFactory.setHttpClient(client);
        restTemplate.setRequestFactory(requestFactory);
    }
}
