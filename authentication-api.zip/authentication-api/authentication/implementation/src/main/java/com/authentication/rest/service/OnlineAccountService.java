package com.authentication.rest.service;

import com.authentication.rest.request.OnlineAccountRequest;
import com.authentication.rest.response.AccountCreationResponse;
/**
 * OnlineAccountService Interface for methods related to OnlineAccount
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public interface OnlineAccountService {
    AccountCreationResponse createNewOnlineAccount(OnlineAccountRequest onlineAccountRequest);
}
