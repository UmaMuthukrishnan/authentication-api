package com.authentication.rest.config;

import com.authentication.rest.restTemplate.AccountAPIRestTemplateCustomizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RestTemplateConfig -Config class for customizing the restTemplate
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Configuration
public class RestTemplateConfig {

    private final AccountAPIRestTemplateCustomizer accountAPIRestTemplateCustomizer;

    @Autowired
    public RestTemplateConfig(AccountAPIRestTemplateCustomizer accountAPIRestTemplateCustomizer) {
        this.accountAPIRestTemplateCustomizer = accountAPIRestTemplateCustomizer;
    }

    @Bean
    public RestTemplateBuilder restTemplateBuilder() {
        return new RestTemplateBuilder(accountAPIRestTemplateCustomizer);
    }

}
