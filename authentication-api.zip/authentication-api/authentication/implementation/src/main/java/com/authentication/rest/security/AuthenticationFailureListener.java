package com.authentication.rest.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.stereotype.Component;

/**
 * AuthenticationFailureListener class for listening AuthenticationFailureBadCredentialsEvent
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class AuthenticationFailureListener implements ApplicationListener<AuthenticationFailureBadCredentialsEvent> {

    private final LoginValidationService loginValidationService;

    @Autowired
    public AuthenticationFailureListener(LoginValidationService loginValidationService) {
        this.loginValidationService = loginValidationService;
    }

    /**
     * Method to listen AuthenticationFailureBadCredentialsEvent and stores in a cache
     * inside loginValidationService for UserAccount Access validation.
     *
     * @param event of AuthenticationFailureBadCredentialsEvent type.
     */
    @Override
    public void onApplicationEvent(AuthenticationFailureBadCredentialsEvent event) {
        Object credentials = event.getAuthentication().getCredentials();
        if (credentials != null) {
            String userName = event.getAuthentication().getPrincipal().toString();
            loginValidationService.loginFailed(userName);
        }

    }
}
