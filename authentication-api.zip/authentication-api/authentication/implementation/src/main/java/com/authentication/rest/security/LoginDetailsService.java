package com.authentication.rest.security;

import com.authentication.rest.model.LoginDetails;
import org.springframework.stereotype.Component;

/**
 * LoginDetailsService class for  userCredentials
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class LoginDetailsService {

    private LoginDetails loginDetails;

    public LoginDetailsService() {
        loginDetails = null;
    }

    public void setLoginDetails(LoginDetails details) {
        loginDetails = details;
    }

    public LoginDetails retrieveLoginDetails() {
        return loginDetails;
    }
}
