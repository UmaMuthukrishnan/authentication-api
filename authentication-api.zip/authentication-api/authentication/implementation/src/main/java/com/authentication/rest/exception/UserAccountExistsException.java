package com.authentication.rest.exception;

import com.authentication.rest.model.AuthenticationApiError;
import lombok.Getter;

/**
 * UserAccountExistsException Exception for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class UserAccountExistsException extends GenericException {
    private static final long serialVersionUID = 1L;

    String message;

    public UserAccountExistsException(AuthenticationApiError authenticationApiError, String message) {
        super(authenticationApiError);
        this.message = message;

    }
}
