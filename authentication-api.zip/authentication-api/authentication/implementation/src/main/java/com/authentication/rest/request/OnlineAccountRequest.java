package com.authentication.rest.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * OnlineAccountRequest class with OnlineAccount details
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OnlineAccountRequest implements Serializable {
    private static final long serialVersionUID = 4926468583005150707L;
    private String accountNumber;
    private String userName;
    private String password;
}
