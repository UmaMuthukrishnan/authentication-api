package com.authentication.rest.controller;

import com.authentication.rest.request.LoginRequest;
import com.authentication.rest.request.OnlineAccountRequest;
import com.authentication.rest.response.AccountCreationResponse;
import com.authentication.rest.response.JwtResponse;
import com.authentication.rest.service.AuthenticationService;
import com.authentication.rest.service.OnlineAccountService;
import com.authentication.rest.util.UserRequestValidator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Rest Controller class for AccountAuthentication
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@RestController
@RequestMapping("/accountAuthentication")
@Slf4j
public class AccountAuthenticationController {
    private final AuthenticationService authenticationService;
    private final OnlineAccountService onlineAccountService;

    @Autowired
    public AccountAuthenticationController(OnlineAccountService onlineAccountService, AuthenticationService authenticationService) {
        this.onlineAccountService = onlineAccountService;
        this.authenticationService = authenticationService;
    }

    /**
     * Create an OnlineUserAccount for an User
     *
     * @param onlineAccountRequest Request with { String userName,String Password,String accountNumber}
     *                             in json format
     * @return AccountCreationResponse in case of Success
     */
    @PostMapping(value = "/createOnlineAccount"
            , consumes = MediaType.APPLICATION_JSON_VALUE
            , produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "To create Online User Account")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully created "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<AccountCreationResponse> createOnlineAccount(@RequestBody OnlineAccountRequest onlineAccountRequest) {
        UserRequestValidator.validateOnlineAccountRequest(onlineAccountRequest);
        log.info("Request to create new user online account - {}", onlineAccountRequest.getAccountNumber());
        AccountCreationResponse successMessage = onlineAccountService.createNewOnlineAccount(onlineAccountRequest);
        return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
    }

    /**
     * Authenticates user with valid userName & password
     *
     * @param loginRequest Request with { String username,String Password}
     *                     in json format
     * @return JwtResponse with valid jwtToken
     * @throws Exception in case of invalid user credentials
     */
    @PostMapping(value = "/authenticateUser", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "To create JWT Token for Authenticated User")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully created "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<JwtResponse> createAuthenticationToken(@RequestBody LoginRequest loginRequest) throws Exception {
        UserRequestValidator.validateLoginRequest(loginRequest);
        log.info("Request to create JWT token for the user - {}", loginRequest.getUsername());
        JwtResponse jwtResponse = authenticationService.getAuthenticationToken(loginRequest);
        return new ResponseEntity<>(jwtResponse, HttpStatus.CREATED);
    }

}
