package com.authentication.rest.model;

import lombok.*;
import org.springframework.stereotype.Component;

/**
 * LoginDetails Model class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginDetails {
    private String userName;
    private String password;
}
