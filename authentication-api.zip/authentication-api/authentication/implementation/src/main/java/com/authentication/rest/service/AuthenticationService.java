package com.authentication.rest.service;

import com.authentication.rest.request.LoginRequest;
import com.authentication.rest.response.JwtResponse;
/**
 * AuthenticationService Interface for methods related to Account Authentication
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public interface AuthenticationService {
    JwtResponse getAuthenticationToken(LoginRequest loginRequest) throws Exception;
}
