package com.authentication.rest.service.impl;

import com.authentication.rest.exception.UserAccountBlockedException;
import com.authentication.rest.model.AuthenticationApiError;
import com.authentication.rest.model.LoginDetails;
import com.authentication.rest.request.LoginRequest;
import com.authentication.rest.response.JwtResponse;
import com.authentication.rest.security.LoginDetailsService;
import com.authentication.rest.security.LoginUserDetailsService;
import com.authentication.rest.service.AuthenticationService;
import com.authentication.rest.util.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

/**
 * AuthenticationServiceImpl class -Implementation of AuthenticationService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
@Slf4j
public class AuthenticationServiceImpl implements AuthenticationService {
    private final LoginUserDetailsService loginUserDetailsService;
    private final JwtTokenUtil jwtTokenUtil;
    private final AuthenticationManager authenticationManager;
    private final LoginDetailsService loginDetailsService;

    private static final String USER_ACCOUNT_LOCKED_ERROR_CODE = "AUTHAPI-USER_ACCOUNT_LOCKED-011";
    private static final String USER_ACCOUNT_LOCKED_ERROR_DESC = "USER_ACCOUNT_LOCKED";

    @Autowired
    public AuthenticationServiceImpl(LoginUserDetailsService loginUserDetailsService, JwtTokenUtil jwtTokenUtil
            , AuthenticationManager authenticationManager, LoginDetailsService loginDetailsService) {
        this.loginUserDetailsService = loginUserDetailsService;
        this.jwtTokenUtil = jwtTokenUtil;
        this.authenticationManager = authenticationManager;
        this.loginDetailsService = loginDetailsService;
    }

    /**
     * Method to validate and authenticate the user with valid credentials for generating the JWT token
     * <p>
     * This method checks for unique userName and password for validating the user details
     * with the in-memory datastore.If valid data exists then it authenticates
     * the user for generating the valid JWT token.
     *
     * @param loginRequest Request with { String username,String Password}
     *                     in json format
     * @return JwtResponse with valid jwtToken
     * @throws Exception in case of invalid user credentials
     */
    @Override
    public JwtResponse getAuthenticationToken(LoginRequest loginRequest) throws Exception {
        authenticate(loginRequest.getUsername(), loginRequest.getPassword());
        loginDetailsService.setLoginDetails(LoginDetails.builder()
                .userName(loginRequest.getUsername()).password(loginRequest.getPassword()).build());
        final UserDetails userDetails = loginUserDetailsService
                .loadUserByUsername(loginRequest.getUsername());
        final String token = jwtTokenUtil.generateToken(userDetails);
        return JwtResponse.builder().jwtToken(token).build();
    }

    /**
     * Method to authenticate the user with his credentials.
     * <p>
     * It authenticates using UsernamePasswordAuthenticationToken and provides a valid response
     * or else throws valid exception.
     *
     * @param username username as String
     * @param password username as String
     * @throws Exception incase of exception/ with invalid credentials
     */
    private void authenticate(String username, String password) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (Exception exception) {
            if (exception instanceof UserAccountBlockedException) {
                throw new UserAccountBlockedException(new AuthenticationApiError(USER_ACCOUNT_LOCKED_ERROR_CODE
                        , USER_ACCOUNT_LOCKED_ERROR_DESC, HttpStatus.BAD_REQUEST), "User Account is locked!");
            }
        }
    }
}
