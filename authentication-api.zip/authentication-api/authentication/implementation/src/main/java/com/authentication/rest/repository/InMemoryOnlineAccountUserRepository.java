package com.authentication.rest.repository;

import com.authentication.rest.model.OnlineAccountUser;
import com.authentication.rest.util.OnlineAccountUserSerializer;
import net.openhft.chronicle.map.ChronicleMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * InMemoryOnlineAccountUserRepository class - Implementation of OnlineAccountUserRepository
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Component
public class InMemoryOnlineAccountUserRepository implements OnlineAccountUserRepository {

    private final ChronicleMap<String, OnlineAccountUser> inMemoryOnlineAccountMap;
    private final ChronicleMap<String, String> inMemoryUserAccountMap;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public InMemoryOnlineAccountUserRepository(PasswordEncoder passwordEncoder) {
        this.inMemoryOnlineAccountMap = createInMemoryOnlineAccountMap();
        this.inMemoryUserAccountMap = createInMemoryUserAccountMap();
        this.passwordEncoder = passwordEncoder;

    }

    /**
     * Custom method to save the valid OnlineAccountUser in
     * in-Memory Map (Chronicle Map) named "online-account-map".
     * It also saves the details in another in-Memory Map (Chronicle Map) named
     * "user-account-map" to maintain the Account/User relationship
     *
     * @param onlineAccountUser - OnlineAccountUser Object to be saved in "online-account-map"
     * @return saved OnlineAccountUser object
     */
    @Override
    public OnlineAccountUser save(OnlineAccountUser onlineAccountUser) {
        Objects.requireNonNull(onlineAccountUser);
        String userName = onlineAccountUser.getUserName().toLowerCase();
        String accountNumber = onlineAccountUser.getAccountNumber();
        inMemoryOnlineAccountMap.put(userName, onlineAccountUser);
        inMemoryUserAccountMap.put(accountNumber, userName);
        return onlineAccountUser;
    }

    /**
     * Custom method to find account number from in-Memory Map (Chronicle Map)
     * named "user-account-map" for valid accountNumber
     *
     * @param accountNumber user A/C number as String
     * @return A/C number wrapped in Optional object
     */
    @Override
    public Optional<String> findByAccountNumber(String accountNumber) {
        Objects.requireNonNull(accountNumber);
        return Optional.ofNullable(inMemoryUserAccountMap.get(accountNumber));
    }

    /**
     * Custom method to find Online account details from in-Memory Map (Chronicle Map)
     * named "online-account-map" for valid userName
     *
     * @param userName userName as String
     * @return OnlineAccountUser  wrapped in Optional object
     */
    @Override
    public Optional<OnlineAccountUser> findByUserName(String userName) {
        Objects.requireNonNull(userName);
        return Optional.ofNullable(inMemoryOnlineAccountMap.get(userName.toLowerCase()));
    }

    /**
     * Custom method to find Online account details from in-Memory Map (Chronicle Map)
     * named "online-account-map" for valid userName and password
     *
     * @param userName userName as String
     * @param password password as String
     * @return OnlineAccountUser  wrapped in Optional object
     */
    @Override
    public Optional<OnlineAccountUser> findByUserNameAndPassword(String userName, String password) {
        Optional<OnlineAccountUser> optionalOnlineAccountUser = findByUserName(userName);
        if (optionalOnlineAccountUser.isPresent()) {
            OnlineAccountUser existingUser = optionalOnlineAccountUser.get();
            String existingPassword = existingUser.getPassword();
            if (passwordEncoder.matches(password, existingPassword)) {
                return optionalOnlineAccountUser;
            }
        }
        return Optional.empty();
    }

    /**
     * Custom method to find if user A/C number already exists
     * in in-Memory Map (Chronicle Map) "user-account-map"
     *
     * @param accountNumber user A/C number as String
     * @return boolean (true/false)
     */
    @Override
    public boolean findIfAccountNumberExists(String accountNumber) {
        Objects.requireNonNull(accountNumber);
        boolean onlineAccountExists = false;
        Optional<String> optionalOnlineAccount = findByAccountNumber(accountNumber);
        if (optionalOnlineAccount.isPresent()) {
            onlineAccountExists = true;
        }
        return onlineAccountExists;
    }

    /**
     * Custom method to find if userName already exists
     * in in-Memory Map (Chronicle Map) "online-account-map"
     *
     * @param userName userName as String
     * @return boolean (true/false)
     */
    @Override
    public boolean findIfUserNameExists(String userName) {
        Objects.requireNonNull(userName);
        boolean onlineUserExists = false;
        Optional<OnlineAccountUser> optionalOnlineAccountUser = findByUserName(userName);
        if (optionalOnlineAccountUser.isPresent()) {
            OnlineAccountUser existingUser = optionalOnlineAccountUser.get();
            if (userName.equalsIgnoreCase(existingUser.getUserName())) {
                onlineUserExists = true;
            }
        }
        return onlineUserExists;
    }

    /**
     * Custom method to find all the existing OnlineAccountUser from
     * in in-Memory Map (Chronicle Map) "online-account-map"
     *
     * @return List of OnlineAccountUser -List<OnlineAccountUser>
     */
    @Override
    public List<OnlineAccountUser> findAll() {
        return new ArrayList<>(inMemoryOnlineAccountMap.values());
    }

    /**
     * Method to create an In-Memory map "ChronicleMap" named "online-account-map" for
     * <p>
     * better reliability and access than concurretHashMap
     * <p>
     * This map used to store all the OnlineAccountUser user details with "userName" as key
     *
     * @return ChronicleMap<String, OnlineAccountUser>
     */
    private ChronicleMap<String, OnlineAccountUser> createInMemoryOnlineAccountMap() {
        return ChronicleMap
                .of(String.class, OnlineAccountUser.class)
                .name("online-account-map")
                .entries(100000)
                .averageKeySize(4)
                .averageValueSize(1000)
                .valueMarshaller(OnlineAccountUserSerializer.getInstance())
                .create();
    }

    /**
     * Method to create an In-Memory map "ChronicleMap" named "user-account-map" for
     * <p>
     * better reliability and access than concurretHashMap
     * <p>
     * This map used to store all the Account/user details with "accountNumber" as key
     *
     * @return ChronicleMap<String, String>
     */
    private ChronicleMap<String, String> createInMemoryUserAccountMap() {
        return ChronicleMap
                .of(String.class, String.class)
                .name("user-account-map")
                .entries(100000)
                .averageKeySize(4)
                .averageValueSize(1000)
                .create();
    }


}
