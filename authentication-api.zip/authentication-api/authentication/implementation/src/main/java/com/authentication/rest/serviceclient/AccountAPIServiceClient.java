package com.authentication.rest.serviceclient;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * AccountAPIServiceClient to consume AccountAPI service
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
@Slf4j
public class AccountAPIServiceClient {

    @Value("${account-api-service-url}")
    private String accountAPIServiceUrl;

    private final RestTemplate restTemplate;


    @Autowired
    public AccountAPIServiceClient(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }

    /**
     * Method to consume AccountAPI service to get the account details using a valid accountNumber.
     * Uses RestTemplate for the exchange
     *
     * @param accountNumber user entered accountNumber
     * @return String as Optional object
     */
    public Optional<String> getAccountAPIDetails(String accountNumber) {
        log.info("getAccountAPIDetails :: START {} ", LocalDateTime.now());
        long startTime = System.currentTimeMillis();
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(accountAPIServiceUrl)
                .path(accountNumber);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        Optional<ResponseEntity<String>> stringOptionalResponse = Optional.of(restTemplate.exchange(uriBuilder.toUriString(),
                HttpMethod.GET, entity, String.class));
        String response = stringOptionalResponse.map(HttpEntity::getBody).orElse(null);
        try {
            Thread.sleep(1000L);
        } catch (InterruptedException e) {
            log.info("Interrupted Exception occurred :" + e.getCause());
        }
        long endTime = System.currentTimeMillis();
        double time = (endTime - startTime) / 1000.000;
        log.info("getAccountAPIDetails :: END time: {} seconds", time);
        return Optional.ofNullable(response);

    }


}
