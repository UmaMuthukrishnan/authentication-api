package com.authentication.rest.service.impl;

import com.authentication.rest.config.APIConstants;
import com.authentication.rest.exception.InvalidAccountDetailsException;
import com.authentication.rest.exception.UserAccountExistsException;
import com.authentication.rest.exception.UserNameExistsException;
import com.authentication.rest.model.AuthenticationApiError;
import com.authentication.rest.model.OnlineAccountUser;
import com.authentication.rest.repository.OnlineAccountUserRepository;
import com.authentication.rest.request.OnlineAccountRequest;
import com.authentication.rest.response.AccountCreationResponse;
import com.authentication.rest.service.OnlineAccountService;
import com.authentication.rest.serviceclient.AccountAPIServiceClient;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * OnlineAccountServiceImpl class -Implementation of OnlineAccountService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Service
@Slf4j
public class OnlineAccountServiceImpl implements OnlineAccountService {
    private final AccountAPIServiceClient accountAPIServiceClient;
    private final OnlineAccountUserRepository onlineAccountUserRepository;
    private final PasswordEncoder bcryptEncoder;

    @Autowired
    public OnlineAccountServiceImpl(AccountAPIServiceClient accountAPIServiceClient
            , OnlineAccountUserRepository onlineAccountUserRepository, PasswordEncoder bcryptEncoder) {
        this.accountAPIServiceClient = accountAPIServiceClient;
        this.onlineAccountUserRepository = onlineAccountUserRepository;
        this.bcryptEncoder = bcryptEncoder;
    }

    /**
     * Method to create an new onlineUserAccount for an user
     * <p>
     * This method validates if the user entered account details from user exists in AccountAPI service
     * via restAPI call using an accountAPIServiceClient.
     * <p>
     * If account exists in AccountAPI,then it validates whether the
     * user entered userName and password exists in in-Memory datastore.If not exists then
     * it will allow the user to create an OnlineUserAccount else it will throw respective exceptions.
     * <p>
     * Note:User entered userName is validated for uniqueness using case-insensitive approach .
     * i.e. If user enters userName as "ABCEdrfGYH" and if the name exists in the
     * database with similar characters "abceDRFgYh" then it considers both as same.
     *
     * @param onlineAccountRequest Request with { String userName,String Password,String accountNumber}
     *                             in json format
     * @return AccountCreationResponse in case of Success
     */
    @Override
    public AccountCreationResponse createNewOnlineAccount(OnlineAccountRequest onlineAccountRequest) {
        String accountNumber = onlineAccountRequest.getAccountNumber();
        Optional<String> accountAPIResponse = accountAPIServiceClient.getAccountAPIDetails(accountNumber);
        if (accountAPIResponse.isPresent()) {
            boolean userAccountExists = onlineAccountUserRepository.findIfAccountNumberExists(accountNumber);
            if (!userAccountExists) {
                String userName = onlineAccountRequest.getUserName();
                String password = onlineAccountRequest.getPassword();
                boolean userNameAlreadyExists = onlineAccountUserRepository.findIfUserNameExists(userName);
                if (!userNameAlreadyExists) {
                    OnlineAccountUser mappedOnlineAccountUser = mapUserAccountDetails(accountAPIResponse.get(), userName, password, accountNumber);
                    onlineAccountUserRepository.save(mappedOnlineAccountUser);
                } else {
                    throw new UserNameExistsException(new AuthenticationApiError(APIConstants.USERNAME_EXISTS_ERROR_CODE
                            , APIConstants.USERNAME_EXISTS_ERROR_DESC, HttpStatus.BAD_REQUEST), "UserName already exists!!");
                }
            } else {
                throw new UserAccountExistsException(new AuthenticationApiError(APIConstants.USER_ACCOUNT_EXISTS_ERROR_CODE
                        , APIConstants.USER_ACCOUNT_EXISTS_ERROR_DESC, HttpStatus.BAD_REQUEST), "Online Account already exists!!");
            }
        } else {
            throw new InvalidAccountDetailsException(new AuthenticationApiError(APIConstants.INVALID_ACCOUNT_ERROR_CODE
                    , APIConstants.INVALID_ACCOUNT_ERROR_DESC, HttpStatus.NOT_FOUND), "Please enter valid account details!!");
        }
        return AccountCreationResponse.builder().response(APIConstants.SUCCESS_MESSAGE).build();
    }

    /**
     * Method to map the user entered details and AccountAPI response
     * with valid fields in OnlineAccountUser object.
     * <p>
     * Uses JSONObject for extracting {iban,ownerId}values from AccountAPI response json
     *
     * @param accountAPIResponse response from AccountAPI
     * @param userName           user entered userName
     * @param password           user entered password
     * @param accountNumber      user entered accountNumber
     * @return OnlineAccountUser
     */
    private OnlineAccountUser mapUserAccountDetails(String accountAPIResponse, String userName, String password, String accountNumber) {
        JSONObject jsonObject = new JSONObject(accountAPIResponse);
        String ibanNumber = jsonObject.optString("iban");
        String ownerId = jsonObject.optString("ownerId");
        return OnlineAccountUser.builder()
                .accountNumber(accountNumber)
                .userName(userName)
                .password(bcryptEncoder.encode(password))
                .ibanNumber(ibanNumber)
                .ownerId(ownerId)
                .build();
    }

}
