package com.authentication.rest.repository;

import com.authentication.rest.model.OnlineAccountUser;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * OnlineAccountUserRepository Interface - Custom repository to store the
 * persisted OnlineAccountUser data. Acts as a in-memory datastore.
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Component
public interface OnlineAccountUserRepository {

    OnlineAccountUser save(final OnlineAccountUser onlineAccountUser);

    Optional<String> findByAccountNumber(String accountNumber);

    Optional<OnlineAccountUser> findByUserName(String userName);

    Optional<OnlineAccountUser> findByUserNameAndPassword(String userName, String password);

    boolean findIfAccountNumberExists(String accountNumber);

    boolean findIfUserNameExists(String userName);

    List<OnlineAccountUser> findAll();


}
