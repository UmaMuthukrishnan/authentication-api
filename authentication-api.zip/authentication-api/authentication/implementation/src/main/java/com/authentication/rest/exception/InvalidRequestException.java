package com.authentication.rest.exception;


import com.authentication.rest.model.AuthenticationApiError;
import lombok.Getter;


/**
 * InvalidRequestException Exception for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
public class InvalidRequestException extends GenericException {

    String message;

    public InvalidRequestException(AuthenticationApiError authenticationApiError, String message) {
        super(authenticationApiError);
        this.message = message;

    }
}
